const pool = require('../database');

const favoriteController = {
  // Add to favorites
  addFavorite: async (req, res) => {
    try {
      const { userId, placeId } = req.body;

      const [result] = await pool.query(
        `INSERT INTO favorites (user_id, place_id)
         VALUES (?, ?)`,
        [userId, placeId]
      );

      res.json({ 
        success: true,
        message: 'Added to favorites',
        favoriteId: result.insertId
      });

    } catch (error) {
      console.error('Add favorite error:', error);
      res.status(500).json({ 
        success: false,
        message: 'Failed to add favorite'
      });
    }
  },

  // Remove from favorites
  removeFavorite: async (req, res) => {
    try {
      const { userId, placeId } = req.body;

      await pool.query(
        `DELETE FROM favorites 
         WHERE user_id = ? AND place_id = ?`,
        [userId, placeId]
      );

      res.json({ 
        success: true,
        message: 'Removed from favorites'
      });

    } catch (error) {
      console.error('Remove favorite error:', error);
      res.status(500).json({ 
        success: false,
        message: 'Failed to remove favorite'
      });
    }
  },

  // Get user favorites
  getFavorites: async (req, res) => {
    try {
      const { userId } = req.params;

      const [favorites] = await pool.query(
        `SELECT * FROM favorites 
         WHERE user_id = ?`,
        [userId]
      );

      res.json({
        success: true,
        favorites
      });

    } catch (error) {
      console.error('Get favorites error:', error);
      res.status(500).json({ 
        success: false,
        message: 'Failed to get favorites'
      });
    }
  }
};

module.exports = favoriteController;
