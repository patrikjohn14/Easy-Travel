const pool = require('../database');

const getUserProfile = async (req, res) => {
  const userId = req.params.id; 

  try {
    const [rows] = await pool.query(
      'SELECT id, first_name, last_name, email, bio , profile_picture FROM users WHERE id = ?',
      [userId]
    );

    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'User Not Found !' });
    }

    const user = rows[0];
    

    const userWithBase64 = {
      ...user,
      profile_picture: user.profile_picture ? user.profile_picture.toString('base64') : null
    };

    res.json({ success: true, user: userWithBase64 });
  } catch (error) {
    console.error('خطأ أثناء جلب بيانات المستخدم:', error);
    res.status(500).json({ success: false, message: 'حدث خطأ أثناء جلب البيانات' });
  }
};


const updateUserProfile = async (req, res) => {
  const userId = req.params.id;
  const { first_name, last_name, bio, profile_picture } = req.body;

  // التحقق من صحة البيانات المدخلة
  if (!userId || isNaN(userId)) {
    return res.status(400).json({ success: false, message: 'Invalid user ID!' });
  }

  try {
    // تنفيذ الاستعلام
    const [result] = await pool.query(
      `UPDATE users 
       SET first_name = ?, 
           last_name = ?, 
           bio = ?, 
           profile_picture = ? 
       WHERE id = ?`,
      [first_name || null, last_name || null, bio || null, profile_picture || null, userId]
    );

    // التحقق من تحديث البيانات
    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'User Not Found!' });
    }

    res.json({ success: true, message: 'User updated successfully!' });
  } catch (error) {
    console.error('Error updating user profile:', error);
    res.status(500).json({ success: false, message: 'An error occurred while updating user data.' });
  }
};


module.exports = {
  getUserProfile,
  updateUserProfile,
};

